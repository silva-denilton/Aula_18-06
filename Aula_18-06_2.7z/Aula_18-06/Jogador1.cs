﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_18_06
{
    internal class Jogador1
    {
        public int Valor1;
        public int Valor2;
        public int Valor3;

      public int Media1()
        {
            return (Valor1 + Valor2 + Valor3) / 3;
        }

    }
   
}
